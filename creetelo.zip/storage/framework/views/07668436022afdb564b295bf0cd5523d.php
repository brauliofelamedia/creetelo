<?php $__env->startPush('css'); ?>
<style>
    li {
        list-style-type: none;
        display: inline;
    }

    ul {
        margin:0 auto;
        text-align: center;
    }

    .btn-pagination,.btn-pagination:hover {
        margin-top: 30px;
        padding: 5px 10px;
        background-color: #474588;
        color: white;
        border-radius: 5px;
    }

    .btn-pagination.active,.btn-pagination:hover {
        background-color: #d17d24;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="about-us-banner pt-120" style="background-image: url('<?php echo e(asset('images/banner.png')); ?>')">
        <div class="about-three-rapper position-relative">
            <img src="<?php echo e(asset('images/shape/shape-2.png')); ?>" alt="" class="shape shape-12">
            <img src="<?php echo e(asset('images/shape/shape-3.png')); ?>" alt="" class="shape shape-13">
            <div class="container">
                <div class="text-center row d-flex align-items-center justify-content-center flex-column">
                    <div class="d-flex align-items-center justify-content-center mt-240 md-mt-100">
                        <h1 class="mb-130 mt-100">Créetelo es una comunidad que empodera a emprendedoras auténticas que quieren aportar a la vida de otros desde su propósito y sus conocimientos.</h1>
                    </div>
                    <div class="mt-20 d-flex align-items-center justify-content-center">
                        <form class="form-3 d-flex align-items-center justify-content-between" action="<?php echo e(route('front.home')); ?>" method="get">
                            <input type="text" name="name" id="searchInput" placeholder="Michelle Poler"  value="<?php echo e(@$name); ?>">
                            <button type="submit" class="btn-search">Buscar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="feature-job-grid pb-90 pt-90">
        <div class="feature-job-grid-rapper">
            <div class="container">
                <div class="px-0 row d-flex align-items-center">
                    <?php if(count($data['contacts']) >= 1): ?>
                        <div class="row job-grid-heading">
                            <div class="col-lg-8 md-pb-20" data-aos="zoom-in">
                                <div class="left-grid">
                                    <span class="">Mostrando <?php echo e(count($data['contacts'])); ?> de <?php echo e($data['total']); ?> candidatos</span>
                                </div>
                            </div>
                            <div class="col-lg-4" data-aos="zoom-in">
                                <div class="right-grid d-flex align-items-center">
                                    <span>Filtrar por</span>
                                    <select class="form-select" aria-label="Default select example">
                                        <option selected>Habilidades</option>
                                        <option value="1">Design</option>
                                        <option value="2">Marketing</option>
                                        <option value="3">web Design</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php $__currentLoopData = $data['contacts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-3">
                                <div class="candidates-1 d-flex flex-column align-items-center justify-content-center">
                                    <div class="round-pic"><img src="<?php echo e($contact['avatar']); ?>" alt=""></div>
                                    <div class="Candidates-grid">
                                        <div class="mt-20 top-grid-1 d-flex flex-column align-items-center justify-content-center">
                                            <div class=" d-flex flex-column align-items-center justify-content-center">
                                                <h3><?php echo e((($contact['firstNameLowerCase'])? $contact['firstNameLowerCase'] :'-')); ?> <?php echo e((($contact['lastNameLowerCase'])? $contact['lastNameLowerCase'] :'-')); ?></h3>
                                                <?php
                                                    $countries = Config::get('countries.countries');
                                                    $countryName = $countries[$contact['country']] ?? '-';
                                                    ($countryName == 'Mexico')? $countryName = 'México': $countryName;
                                                ?>
                                                <span><?php echo e($countryName); ?></span>
                                                <?php if(count($contact['socials']) > 0): ?>
                                                    <ul class="social-link-front">
                                                        <?php $__currentLoopData = $contact['socials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <a href="<?php echo e($url); ?>" target="_blank"><i class="bi bi-<?php echo e($title); ?>"></i></a>
                                                        </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="pt-20 top-grid-4 d-flex flex-column align-items-center justify-content-center">
                                            <a href="<?php echo e(route('front.contact.detail',$contact['id'])); ?>"><span>Conoce esta Creída</span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $total = $data['total'];
                            $pages = intval(ceil($total / 20));
                        ?>

                        <ul>
                            <?php for($i = 0; $i < $pages; $i++): ?>
                                <li><a href="<?php echo e(route('front.home')); ?>/?page=<?php echo e($i+1); ?>" class="btn-pagination  <?php echo e(($page == $i+1)? 'active':''); ?>"><?php echo e($i+1); ?></a></li>
                            <?php endfor; ?>
                        </ul>

                    <?php else: ?>
                        <h4 class="mb-20 text-center">No hay candidados relacionados con tu búsqueda.</h4>
                        <div class="explore-btn" style="padding:0;">
                            <form action="<?php echo e(route('front.home')); ?>" method="GET">
                                <input type="hidden" name="">
                                <button type="submit" class="btn-custom">Reiniciar busqueda</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="Customer-one">
        <div class="container">
            <div class="customer_rapper">
                <img src="images/shape/shape-4.png" alt="">
                <img src="images/shape/shape-4.png" alt="">
                <div class="row">
                    <div class="text-center col customer_content pt-80 pb-80">
                        <h2 class="">200k+ Customers Regular Visit Our Site.Try it now!</h2>
                        <p class="mb-30">Enthusiastically mesh user friendly content with long-term high-impact architectures. Proactively underwhelm .</p>
                        <a href="" class="custom-btn">Apply Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\creetelo\resources\views/front/home.blade.php ENDPATH**/ ?>
<div class="theme-main-menu sticky-menu theme-menu-one">
	<div class="container inner-content">
		<div class="d-flex align-items-center justify-content-between">
			<div class="d-flex logo order-lg-0"><a href="<?php echo e(route('front.home')); ?>" class="d-block"><img src="<?php echo e(asset('images/Directorio-Logo.png')); ?>" alt="<?php echo e(env('APP_NAME')); ?>" style="width:230px;"></a></div>
			<div class="right-wiget d-lg-flex align-items-center order-lg-3">
				<?php if(auth()->check()): ?>
					<div class="people"><a href="<?php echo e(route('dashboard.account.index')); ?>"><img src="<?php echo e(asset('images/icon/user.svg')); ?>" alt="user"></a></div>
					<a href="<?php echo e(route('logout')); ?>" class="sign-up"><span class="custom-btn"><i class="fas fa-unlock-alt"></i></span></a>
				<?php else: ?>
					<div class="sign-up"><a class="custom-btn" href="<?php echo e(route('filament.admin.auth.login')); ?>">Iniciar sesión</a></div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php /**PATH D:\laragon\www\creetelo\resources\views/layouts/parts/navbar.blade.php ENDPATH**/ ?>
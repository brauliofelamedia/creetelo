<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <style>
        p {
            font-size: 12px;
        }

        .signature {
            font-style: italic;
        }
    </style>
</head>
<body>
<div>
    <a href="<?php echo e(env('APP_URL')); ?>" target="_blank">
        <img src="<?php echo e(env()->url('public/images/logo.png')); ?>" alt="Créetelo" style="width:250px;">
    </a><br>
    <p>Te dejamos los datos para iniciar sesión:😉</p><br>
    <p>Url de acceso: <a href="<?php echo e(env()->url('admin/login')); ?>" target="_blank"><?php echo e(env()->url('admin/login')); ?></a></p>
    <p>Nombre: <?php echo e($name); ?></p>
    <p>Correo electrónico: <?php echo e($email); ?></p>
    <p>Contraseña: <?php echo e($password); ?></p>
    <p class="signature">Créetelo</p>
</div>
</body>
</html>
<?php /**PATH D:\laragon\www\creetelo\resources\views/emails/register.blade.php ENDPATH**/ ?>
<?php $__env->startPush('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .heading-2 {
        font-size: 35px!important;
    }
    .blue {
        padding: 20px;
        background-color: #f3bfa5;
        border-radius: 10px;
    }

    .btn-add {
        background-color: #292775;
        padding: 10px 18px;
        border-radius: 7px;
        color: white !important;
        font-size: 14px !important;
        cursor: pointer;
    }

    .delete-row, .delete-save {
        position: absolute;
        right: 14px;
        padding: 1px 6px;
        font-size: 12px;
        top: 10px;
    }

    #formSocial {
        padding: 30px;
        background-color: #ececec;
        border-radius: 10px;
        margin-top: 20px;
    }

    #btnSocial {
        margin-top: 20px;
    }

    .btn-add:hover {
        background-color: #322f9b;
    }

    label {
        font-weight: 600 !important;
    }

    .form-group {
        margin-bottom: 13px;
    }

    .form-control:focus {
        box-shadow: none;
    }

    button[disabled],button[disabled]:hover {
        background-color: #ccc;
        color: #666;
        cursor: not-allowed;
        opacity: 0.6;
    }

    h3 {
        margin: 10px 0px;
        color: #d17d24;
        font-weight: 600;
        font-size: 23px;
    }

    input, select,textarea {
        padding: 17px!important;
        font-size: 15px!important;
        font-weight: 400!important;
    }

    .avatar {
        width:180px;
        height: 180px;
        position: absolute;
        border-radius: 15px;
        top:-150px;
        left: 300px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        box-shadow:0 0 10px rgba(1,1,1,0.5);
    }

    .btn-succcess {
        background-color: #292775;
        font-weight: 700;
        color: white;
        padding:20px;
        font-size: 15px;
        text-transform: uppercase;
        border-radius: 6px;
        width: 100%;
    }

    .btn-succcess:hover {
        background-color: #1c1a6a;
    }

    h1 {
        color: #292775!important;
    }

    @media (max-width: 992px) {
        .avatar {
            width: 170px;
            height: 170px;
            top: -140px;
            left: 44px;
        }
        .contact-form {
            padding: 40px;
            padding-top: 60px !important;
        }
    }

    @media (max-width: 768px) {
        .avatar {
            width: 110px;
            height: 110px;
            top: -70px;
            left: 38px;
        }

        .contact-form {
            padding:20px;
            padding-top: 60px!important;
        }
    }

    @media (max-width: 480px) {
        .avatar {
            width: 130px;
            height: 130px;
            top: -119px;
            left: 35px;
        }

        .heading-2 {
            font-size: 28px !important;
            margin: 0;
        }

        .contact-form {
            padding:20px;
            padding-top: 40px!important;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="about-us-banner" style="background-image: url('<?php echo e(asset('images/banner-detail.png')); ?>')">
        <div class="about-three-rapper position-relative">
            <img src="<?php echo e(asset('images/shape/shape-2.png')); ?>" alt="" class="shape shape-12">
            <img src="<?php echo e(asset('images/shape/shape-3.png')); ?>" alt="" class="shape shape-13">
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center flex-column">
                    <div class="d-flex align-items-center justify-content-center mt-240 md-mt-100 pb-60">
                        <h1 class="mb-10">Mi cuenta</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="contact-form pt-60 pb-60" style="position:relative;">
        <div class="avatar" style="background-image:url('<?php echo e(Gravatar::fallback($user->avatar)->get($user->email)); ?>');"></div>
        <div class="container">
            <div class="text-left">
                <h2 class="heading-2 mb-30">Hola, <?php echo e($user->fullname); ?></h2>
            </div>
            <?php if($errors->has('ocupation')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('ocupation')); ?></strong>
                </span>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('dashboard.account.update')); ?>" method="post" enctype="multipart/form-data" id="form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Información personal</h3>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Nombre:</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(ucfirst($user->name)); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Apellidos:</label>
                            <input type="text" class="form-control" name="last_name" value="<?php echo e(ucfirst($user->last_name)); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Correo electrónico</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Teléfono:</label>
                            <input class="form-control" type="tel" name="phone" value="<?php echo e($user->phone); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="mb-10 form-label">Ocupación:</label>
                            <input class="form-control" type="text" name="ocupation" value="<?php echo e($user->ocupation); ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="mb-10 form-label">Sobre mi:</label>
                            <textarea name="about_me" rows="5" class="form-control"><?php echo e($user->about_me); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Sobre mí</h3>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Hola! Soy una Creída muy:</label>
                            <textarea class="form-control" name="how_vain"><?php echo e(@$user->additional->how_vain); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Soy increíble en (mis habilidades):</label>
                            <textarea class="form-control" name="skills"><?php echo e(@$user->additional->skills); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Mi emprendimiento trata sobre:</label>
                            <textarea class="form-control" name="business_about"><?php echo e(@$user->additional->business_about); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Trabajo en el corporativo, me dedico a:</label>
                            <textarea class="form-control" name="corporate_job"><?php echo e(@$user->additional->corporate_job); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Mi misión es ayudar a que más personas:</label>
                            <textarea class="form-control" name="mission"><?php echo e(@$user->additional->mission); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Mi audiencia IDEAL es:</label>
                            <textarea class="form-control" name="ideal_audience"><?php echo e(@$user->additional->ideal_audience); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>Prefiero no trabajar con personas que:</label>
                            <textarea class="form-control" name="dont_work_with"><?php echo e(@$user->additional->dont_work_with); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Mis valores más importantes son:</label>
                            <textarea class="form-control" name="values"><?php echo e(@$user->additional->values); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Mi tono es:</label>
                            <textarea class="form-control" name="tone"><?php echo e(@$user->additional->tone); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Entré a Créetelo buscando:</label>
                            <textarea class="form-control" name="looking_for_in_creelo"><?php echo e(@$user->additional->looking_for_in_creelo); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Más sobre TI:</h3>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Dónde naciste y creciste?:</label>
                            <textarea class="form-control" name="birthplace"><?php echo e(@$user->additional->birthplace); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Qué signo eres?:</label>
                            <textarea class="form-control" name="sign"><?php echo e(@$user->additional->sign); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Tienes hobbies?:</label>
                            <textarea class="form-control" name="hobbies"><?php echo e(@$user->additional->hobbies); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Bebida favorita?:</label>
                            <textarea class="form-control" name="favorite_drink"><?php echo e(@$user->additional->favorite_drink); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Tienes hijos?:</label>
                            <textarea class="form-control" name="has_children"><?php echo e(@$user->additional->has_children); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Estás casada?:</label>
                            <textarea class="form-control" name="is_married"><?php echo e(@$user->additional->is_married); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Tu viaje favorito que has hecho?:</label>
                            <textarea class="form-control" name="favorite_trip"><?php echo e(@$user->additional->favorite_trip); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿A dónde te gustaría viajar next?:</label>
                            <textarea class="form-control" name="next_trip"><?php echo e(@$user->additional->next_trip); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Postre favorito?:</label>
                            <textarea class="form-control" name="favorite_dessert"><?php echo e(@$user->additional->favorite_dessert); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label  class="mb-10 form-label">¿Comida favorita? (si, el postre va primero):</label>
                            <textarea class="form-control" name="favorite_food"><?php echo e(@$user->additional->favorite_food); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label  class="mb-10 form-label">¿Qué serie o película recomiendas mucho?:</label>
                            <textarea class="form-control" name="movie_recommendation"><?php echo e(@$user->additional->movie_recommendation); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label  class="mb-10 form-label">¿Qué libro recomiendas? (Aparte de Hello Fears, obvi):</label>
                            <textarea class="form-control" name="book_recommendation"><?php echo e(@$user->additional->book_recommendation); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label  class="mb-10 form-label">¿Qué PODCAST amas?:</label>
                            <textarea class="form-control" name="podcast_recommendation"><?php echo e(@$user->additional->podcast_recommendation); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Para cerrar:</h3>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Qué te hace IRREMPLAZABLE?:</label>
                            <textarea class="form-control" name="irreplaceable"><?php echo e(@$user->additional->irreplaceable); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Algún LOGRO que nos quieras compartir importante para ti?:</label>
                            <textarea class="form-control" name="achievement"><?php echo e(@$user->additional->achievement); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Te atreves a contarnos tu sueño más grande? #manifiestababy:</label>
                            <textarea class="form-control" name="biggest_dream"><?php echo e(@$user->additional->biggest_dream); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Qué te gustaría recibir?:</label>
                            <textarea class="form-control" name="like_to_receive"><?php echo e(@$user->additional->like_to_receive); ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="mb-10 form-label">¿Qué te hace bien o te trae felicidad?</label>
                            <textarea class="form-control" name="brings_you_happiness"><?php echo e(@$user->additional->brings_you_happiness); ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="blue">
                    <div class="row">
                        <div class="col-xl-12">
                            <h3>Somos abundantes:</h3>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="mb-10 form-label">¿Qué te gustaría regalar? (Una guía, una meditación, un producto, una mentoría, una sesión, una clase...):</label>
                                <textarea class="form-control" name="gift"><?php echo e(@$user->additional->gift); ?></textarea>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="mb-10 form-label">Comparte un link:</label>
                                <input type="text" class="form-control" name="gift_link" value="<?php echo e(@$user->additional->gift_link); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Ubicación</h3>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="form-label">País</label>
                            <select name="country" class="form-control">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($code); ?>" <?php echo e(($user->country == $code)? 'selected':''); ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="mb-10 form-label">Estado:</label>
                            <input class="form-control" type="text" name="state" value="<?php echo e($user->state); ?>">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="mb-10 form-label">Ciudad:</label>
                            <input class="form-control" type="text" name="city" value="<?php echo e($user->city); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <h3>Información extra</h3>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="mb-10 form-label">Código postal:</label>
                            <input class="form-control" type="text" name="postal_code" value="<?php echo e($user->postal_code); ?>">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="mb-10 form-label">Dirección:</label>
                            <input class="form-control" type="text" name="address" value="<?php echo e($user->address); ?>">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="mb-10 form-label">Empresa / emprendimiento:</label>
                            <input class="form-control" type="text" name="company_or_venture" value="<?php echo e($user->company_or_venture); ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Habilidades:</label>
                            <select class="select2 form-control" name="abilities[]" multiple="multiple">
                                <?php if(isset($userSkills)): ?>
                                    <?php if(count($userSkills) > 0): ?>
                                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($skill->id); ?>" <?php if(in_array($skill->id, $userSkills)): ?> selected <?php endif; ?>><?php echo e($skill->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($skill->id); ?>"><?php echo e($skill->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skill->id); ?>"><?php echo e($skill->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Servicios:</label>
                            <select class="select2 form-control" name="services[]" multiple="multiple">
                                <?php if(isset($userServices)): ?>
                                    <?php if(count($userServices) > 0): ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->id); ?>" <?php if(in_array($service->id, $userServices)): ?> selected <?php endif; ?>><?php echo e($service->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn-succcess" id="sendData">Actualizar información</button>
                </form>
                <form action="<?php echo e(route('dashboard.social.update')); ?>" id="formSocial" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <h3>Redes sociales</h3>
                        </div>
                    </div>
                    <?php $__currentLoopData = $user->socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row" style="position: relative;">
                            <div class="col-lg-12">
                                <a data-id="<?php echo e($social->id); ?>" class="btn btn-danger btn-sm delete-save">X</a>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="mb-10 form-label">Red social:</label>
                                    <select name="social[]" class="form-control" required>
                                        <option value="email" <?php if($social->title == 'email'): ?> selected <?php endif; ?>>Email</option>
                                        <option value="whatsapp" <?php if($social->title == 'whatsapp'): ?> selected <?php endif; ?>>Whatsapp</option>
                                        <option value="instagram" <?php if($social->title == 'instagram'): ?> selected <?php endif; ?>>Instagram</option>
                                        <option value="linkedin" <?php if($social->title == 'linkedin'): ?> selected <?php endif; ?>>Linkedin</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="mb-10 form-label">Url:</label>
                                    <input type="text" name="url[]" class="form-control" value="<?php echo e($social->url); ?>" required>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12">
                        <div id="your-container-id"></div>
                        <a id="add-row-btn" class="btn-add">Agregar nueva fila</a>
                    </div>
                    <button type="submit" class="btn-succcess" id="btnSocial">Actualizar redes sociales</button>
                </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).on('click', '.delete-row', function() {
        $(this).closest('.row').remove();
    });
    $(document).ready(function() {

        //Borrado
        $('.delete-save').click(function() {
            var id = $(this).data('id');

            // Confirmar la eliminación
            if (confirm('¿Estás seguro de que deseas eliminar este registro?')) {
                $.ajax({
                    url: '<?php echo e(route('dashboard.social.delete')); ?>',
                    type: 'POST',
                    data: {
                        id: id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        alert(response.message);
                        location.reload();
                    },
                    error: function(error) {
                        // Manejar errores
                        console.error(error);
                        alert('Ocurrió un error al eliminar el registro');
                    }
                });
            }
        });

        $('.select2').select2({
            allowClear: true,
            createTag: function (params) {
                return {
                    id: params.term,
                    text: params.term
                }
            }
        });

        //Add social
        $('#add-row-btn').click(function() {
            $('#your-container-id').append(`
                <div class="row" style="position:relative;">
                    <div class="col-lg-12">
                        <a class="btn btn-danger btn-sm delete-row">X</a>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Red social:</label>
                            <select name="social[]" class="form-control">
                                <option value="email">Email</option>
                                <option value="whatsapp">Whatsapp</option>
                                <option value="instagram">Instagram</option>
                                <option value="linkedin">Linkedin</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="mb-10 form-label">Url:</label>
                            <input type="text" name="url[]" class="form-control">
                        </div>
                    </div>
                </div>
            `);
        });


        let formulario = $('#form');
        let elementosFormulario = formulario.find('input, select, textarea');
        $('#sendData').prop('disabled', true);

        function habilitarBoton() {
            $('#sendData').prop('disabled', false);
        }

        elementosFormulario.on('input', function() {
            habilitarBoton();
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\creetelo\resources\views/front/user/index.blade.php ENDPATH**/ ?>
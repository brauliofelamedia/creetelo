<p class="pt-4 text-sm font-semibold text-gray-600 dark:text-gray-400 border-t">
    Hasnayeen/Themes: <?php echo e(\Composer\InstalledVersions::getPrettyVersion('hasnayeen/themes')); ?>

</p>
<?php /**PATH D:\laragon\www\creetelo\resources\views/vendor/themes/filament/pages/themes-footer.blade.php ENDPATH**/ ?>
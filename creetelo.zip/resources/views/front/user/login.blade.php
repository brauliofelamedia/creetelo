@extends('layouts.main')

@section('content')
    <h1>Login</h1>
@endsection
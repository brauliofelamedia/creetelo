<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Http;
use App\Services\ContactServices;
use Sushi\Sushi;

class Contact extends Model
{
}
